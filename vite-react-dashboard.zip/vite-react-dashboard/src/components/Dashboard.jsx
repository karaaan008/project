
import React, { useEffect, useState } from "react";

function Dashboard() {
  const [location, setLocation] = useState(null);
  const [weather, setWeather] = useState(null);
  const [address, setAddress] = useState(null);
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const goOnline = () => setIsOnline(true);
    const goOffline = () => setIsOnline(false);
    window.addEventListener("online", goOnline);
    window.addEventListener("offline", goOffline);

    if (isOnline) {
      navigator.geolocation.getCurrentPosition(
        async (pos) => {
          const { latitude, longitude } = pos.coords;
          setLocation({ latitude, longitude });

          const weatherKey = "YOUR_OPENWEATHER_API_KEY";
          const geocodeKey = "YOUR_OPENCAGE_API_KEY";

          try {
            const weatherRes = await fetch(
              `https://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&appid=${weatherKey}&units=metric`
            );
            const weatherData = await weatherRes.json();
            setWeather(weatherData);
          } catch (err) {
            console.error("Weather fetch error:", err);
          }

          try {
            const geoRes = await fetch(
              `https://api.opencagedata.com/geocode/v1/json?q=${latitude}+${longitude}&key=${geocodeKey}`
            );
            const geoData = await geoRes.json();
            setAddress(geoData?.results?.[0]?.formatted || "Unknown location");
          } catch (err) {
            console.error("Geocode fetch error:", err);
          }
        },
        (err) => console.error("Geolocation error:", err)
      );
    }

    return () => {
      window.removeEventListener("online", goOnline);
      window.removeEventListener("offline", goOffline);
    };
  }, [isOnline]);

  if (!isOnline) {
    return (
      <div>
        <h3>You are offline</h3>
        <p>Weather and location data are unavailable.</p>
      </div>
    );
  }

  return (
    <div>
      {location && <p>Your Location: {location.latitude}, {location.longitude}</p>}
      {address && <p>Full Address: {address}</p>}
      {weather ? (
        <>
          <p>City: {weather.name}</p>
          <p>Weather: {weather.weather?.[0]?.description || "N/A"}</p>
          <p>Temperature: {weather.main?.temp}°C</p>
        </>
      ) : (
        <p>Loading weather data...</p>
      )}
    </div>
  );
}

export default Dashboard;
